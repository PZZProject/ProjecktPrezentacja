using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;

namespace Projekt
{
    internal class Rumunia : IProblem<string>
    {
        public Rumunia(string start, string goal, Dictionary<string, List<Tuple<string,int>>> neighbours)
        {
            DistanceBucharest = new Dictionary<string, int>();
            InitialState = start;
            GoalState = goal;
            Neighbours = neighbours;
            DistanceBucharest.Add("Arad", 366);
            DistanceBucharest.Add("Bucharest", 0);
            DistanceBucharest.Add("Craiova", 160);
            DistanceBucharest.Add("Drobeta", 242);
            DistanceBucharest.Add("Eforie", 161);
            DistanceBucharest.Add("Fagaras", 176);
            DistanceBucharest.Add("Giurgiu", 77);
            DistanceBucharest.Add("Hirsova", 151);
            DistanceBucharest.Add("Iasi", 226);
            DistanceBucharest.Add("Lugoj", 244);
            DistanceBucharest.Add("Mehadia", 241);
            DistanceBucharest.Add("Neamt", 234);
            DistanceBucharest.Add("Oradea", 380);
            DistanceBucharest.Add("Pitesti", 100);
            DistanceBucharest.Add("Rimnicu_Vilcea", 193);
            DistanceBucharest.Add("Sibiu", 253);
            DistanceBucharest.Add("Timisoara", 329);
            DistanceBucharest.Add("Urziceni", 80);
            DistanceBucharest.Add("Vaslui", 199);
            DistanceBucharest.Add("Zerind", 374);
        }

        public Dictionary<string, int> DistanceBucharest;
        
        public string InitialState { get; }
        
        public string GoalState { get; }
        
        public Dictionary<string, List<Tuple<string,int>>> Neighbours { get; }
        
        public bool IsGoal(string state)
        {
            return state.Equals(GoalState);
        }

        public IList<string> Expand(Node<string> node)
        {
            return (from element in Neighbours[node.State] where !CheckParent(element.Item1, node) select element.Item1).ToList();
        }
        
        public bool CheckParent(string state, Node<string> node)
        {
            while (true)
            {
                if (node == null)
                {
                    return false;
                }
                if (Compare(state, node.State))
                {
                    return true;
                }
                node = node.Parent;
            }
        }

        public void Show(Node<string> node)
        {
            while (node.Parent != null)
            {
                Console.Write(node.State + "<-");
                node = node.Parent;
            }
            Console.WriteLine(node.State);
        }
        
        private static bool Compare(string tmp, string parent)
        {
            return tmp == parent;
        }

        public int Bfs(Node<string> node)
        {
            return node.Heuristic = DistanceBucharest[node.State];
        }

        public int ParentPath(Node<string> node)
        {
            var tmp = new Tuple<string, int>(default(string),default(int));
            if (node.Parent == null) return 0;
            foreach (var element in Neighbours[node.State])
            {
                if (node.Parent.State != element.Item1) continue;
                tmp = element;
                break;
            }
            return  tmp.Item2 + ParentPath(node.Parent);
        }
        
        public int Astar(Node<string> node)
        {
            var tmp = ParentPath(node);
            return node.Heuristic = tmp + DistanceBucharest[node.State];
        }
        
        public int GetHeuristic(Node<string> state)
        {
            return state.Heuristic;
        }
    }
}