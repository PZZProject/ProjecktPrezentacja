﻿using System;
using System.Collections.Generic;

namespace Projekt
{
    //Węzły uniwersalne
    internal class Node<TState>
    {
        public Node(TState s, Node<TState> p)
        {
            Parent = p;
            State = s;
        }
        public TState State { get; }
        public Node<TState> Parent { get; }
        public int Heuristic { get; set; } = -1;
    }

    #region Fringe
    internal interface IFringe<T>
    {
        bool IsEmpty();
        T Remove();
        void Add(T node);
    }

    internal class QueueFringe<T> : IFringe<T>
    {
        private readonly Queue<T> _queue = new Queue<T>();
        public bool IsEmpty()
        {
            return _queue.Count == 0;
        }
        public void Add(T state)
        {
            _queue.Enqueue(state);
        }
        public T Remove()
        {
            return _queue.Dequeue();
        }
    }

    internal class StackFringe<T> : IFringe<T>
    {
        private readonly Stack<T> _stack = new Stack<T>();
        public bool IsEmpty()
        {
            return _stack.Count == 0;
        }

        public void Add(T state)
        {
            _stack.Push(state);
        }

        public T Remove()
        {
            return _stack.Pop();
        }
    }

    internal class SortedFringe<T> : IFringe<T>
    {
        private readonly List<T> _list = new List<T>();
        private readonly Func<T, int> _comp,_getHeu;
        public SortedFringe(Func<T,int> comp,Func<T,int> getHeu)
        {
            _comp = comp;
            _getHeu = getHeu;
        }

        public void Add(T node)
        {
            _comp(node);
            for(var i =0; i < _list.Count; ++i)
            {
                if (_getHeu(node) > _getHeu(_list[i])) continue;
                _list.Insert(i, node);
                return;
            }
            _list.Add(node);
        }

        public bool IsEmpty()
        {
            return _list.Count == 0;
        }

        public T Remove()
        {
            var tmp = _list[0];
            _list.RemoveAt(0);
            return tmp;
        }
    }
    #endregion

    internal interface IProblem<TState>
    {
        TState InitialState { get; }
        bool IsGoal(TState state);
        IList<TState> Expand(Node<TState> state);
    }

    internal class Program
    {
        public static Dictionary<string, List<Tuple<string,int>>> Romania = new Dictionary<string, List<Tuple<string,int>>>();

        private static Node<TState> TreeSearch<TState>(IProblem<TState> p, IFringe<Node<TState>> f )
        {
            f.Add(new Node<TState>(p.InitialState,null));
            while (!f.IsEmpty())
            {
                Node<TState> node = f.Remove();
                if (p.IsGoal(node.State))
                    return node;
                IList<TState> succ = p.Expand(node);
                foreach(var element in succ)
                {
                    f.Add(new Node<TState>(element,node));
                }
            }
            return null;
        }
        private static void Main()
        {
            #region NHetman
            /*
            
            int[] stan = { 3, 0, 0, 3 };
            var het = new Hetmany(stan);
            //var f = new SortedFringe<Node<int[]>>(x => het.Bfs(x),x => het.GetHeuristic(x)); //BFS
            //var f = new SortedFringe<Node<int[]>>(x => het.Astar(x),x => het.GetHeuristic(x)); //A star
            //var f = new QueueFringe<Node<int[]>>();  //Breadth First Search
            //var f = new StackFringe<Node<int[]>>(); //DFS
            var wynik = TreeSearch(het, f);
            Console.WriteLine(wynik != null ? "Found!" : "Not found");
            for (var i = 0; i < wynik.State.GetLength(0); i++)
            {
               Console.Write(wynik.State[i]);
            }
            */
            #endregion
            //----------------------------------------------------------------------------------------
            #region Osemka

            /*
            const int n = 3;
            var pocz = new int[n, n];
            var konc = new int[n, n];
            //----------------------------------------------
            pocz[0, 0] = 4; pocz[0, 1] = 5; pocz[0, 2] = 0;
            pocz[1, 0] = 6; pocz[1, 1] = 1; pocz[1, 2] = 8;
            pocz[2, 0] = 7; pocz[2, 1] = 3; pocz[2, 2] = 2;
            //----------------------------------------------
            konc[0, 0] = 5; konc[0, 1] = 8; konc[0, 2] = 0;
            konc[1, 0] = 4; konc[1, 1] = 6; konc[1, 2] = 1;
            konc[2, 0] = 7; konc[2, 1] = 3; konc[2, 2] = 2;
            var osemka = new Osemka(pocz,konc);
            //var sorted = new SortedFringe<Node<int[,]>>(x => osemka.Bfs(x), x => osemka.GetHeuristic(x)); //BFS
            //var sorted = new SortedFringe<Node<int[,]>>(x => osemka.Astar(x), x => osemka.GetHeuristic(x)); //Astar
            //var sorted = new QueueFringe<Node<int[,]>>(); // Breadth First Search
            //var sorted = new StackFringe<Node<int[,]>>(); // DFS            
            var result = TreeSearch(osemka, sorted);
            */

            #endregion
            //----------------------------------------------------------------------------------------
            #region CitiesofRomania
            
            
            var oradea = new List<Tuple<string,int>> { new Tuple<string, int>("Zerind",71), new Tuple<string, int>("Sibiu",151)};
            var zerind = new List<Tuple<string,int>> { new Tuple<string, int>("Arad",75), new Tuple<string, int>("Oradea",71)};
            var arad = new List<Tuple<string,int>> {new Tuple<string, int>("Timisoara",118), new Tuple<string, int>("Sibiu",140), new Tuple<string, int>("Zerind", 75)};
            var timisoara = new List<Tuple<string,int>> { new Tuple<string, int>("Lugoj",111), new Tuple<string, int>("Arad",118)};
            var lugoj = new List<Tuple<string,int>> {new Tuple<string, int>("Mehadia",70), new Tuple<string, int>("Timisoara",111)};
            var mehadia = new List<Tuple<string,int>> {new Tuple<string, int>("Drobeta",75), new Tuple<string, int>("Lugoj",70)};
            var drobeta = new List<Tuple<string,int>> {new Tuple<string, int>("Craiova",120), new Tuple<string, int>("Mehadia",75)};
            var sibiu = new List<Tuple<string,int>> {new Tuple<string, int>("Arad",140), new Tuple<string, int>("Oradea",151), new Tuple<string, int>("Rimnicu_Vilcea",80), new Tuple<string, int>("Fagaras",99)};
            var riminicuVilcea = new List<Tuple<string,int>> {new Tuple<string, int>("Craiova",146), new Tuple<string, int>("Sibiu",80), new Tuple<string, int>("Pitesti",97)};
            var craiova = new List<Tuple<string,int>> {new Tuple<string, int>("Pitesti",138), new Tuple<string, int>("Drobeta",120), new Tuple<string, int>("Rimnicu_Vilcea",146)};
            var fagaras = new List<Tuple<string,int>> {new Tuple<string, int>("Bucharest",211), new Tuple<string, int>("Sibiu",99)};
            var pitesti = new List<Tuple<string,int>> {new Tuple<string, int>("Bucharest",101), new Tuple<string, int>("Craiova",138), new Tuple<string, int>("Rimnicu_Vilcea",97)};
            var bucharest = new List<Tuple<string,int>> {new Tuple<string, int>("Giurgiu",90), new Tuple<string, int>("Pitesti",101), new Tuple<string, int>("Fagaras",211), new Tuple<string, int>("Urziceni",85)};
            var giurgiu = new List<Tuple<string,int>> {new Tuple<string, int>("Bucharest",90)};
            var neamt = new List<Tuple<string,int>> { new Tuple<string, int>("Iasi",87)};
            var iasi = new List<Tuple<string,int>> {new Tuple<string, int>("Neamt",87), new Tuple<string, int>("Vaslui",92)};
            var vaslui = new List<Tuple<string,int>> {new Tuple<string, int>("Iasi",92), new Tuple<string, int>("Urziceni",142)};
            var urziceni = new List<Tuple<string,int>> {new Tuple<string, int>("Bucharest",85), new Tuple<string, int>("Vaslui",142), new Tuple<string, int>("Hirsova",98)};
            var hirsova = new List<Tuple<string,int>> {new Tuple<string, int>("Urziceni",98), new Tuple<string, int>("Eforie",86)};
            var eforie = new List<Tuple<string,int>> {new Tuple<string, int>("Hirsova",86)};
            Romania.Add("Oradea", oradea);
            Romania.Add("Zerind", zerind);
            Romania.Add("Arad", arad);
            Romania.Add("Timisoara", timisoara);
            Romania.Add("Lugoj", lugoj);
            Romania.Add("Mehadia", mehadia);
            Romania.Add("Drobeta", drobeta);
            Romania.Add("Sibiu", sibiu);
            Romania.Add("Rimnicu_Vilcea", riminicuVilcea);
            Romania.Add("Craiova", craiova);
            Romania.Add("Fagaras", fagaras);
            Romania.Add("Pitesti", pitesti);
            Romania.Add("Bucharest", bucharest);
            Romania.Add("Giurgiu", giurgiu);
            Romania.Add("Neamt", neamt);
            Romania.Add("Iasi", iasi);
            Romania.Add("Vaslui", vaslui);
            Romania.Add("Urziceni", urziceni);
            Romania.Add("Hirsova", hirsova);
            Romania.Add("Eforie", eforie);
            var rumunia = new Rumunia("Arad","Bucharest",Romania);
            //var list = new SortedFringe<Node<string>>(x => rumunia.Bfs(x),x => rumunia.GetHeuristic(x)); // BFS
            var list = new SortedFringe<Node<string>>(x => rumunia.Astar(x),x => rumunia.GetHeuristic(x)); // Astar
            //var list = new StackFringe<Node<string>>(); // DFS
            //var list = new QueueFringe<Node<string>>(); // Breadth First Search
            var result = TreeSearch(rumunia, list);
            rumunia.Show(result);
            
            
            #endregion
            
            Console.ReadKey();
        }
    }
}
