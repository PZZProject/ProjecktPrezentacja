﻿using System.Collections;
using System.Collections.Generic;

namespace Projekt
{
    //Problem N-Hetmatow
    internal class Hetmany : IProblem<int[]>
    {
        public Hetmany(int[] pocz)
        {
            InitialState = pocz;
        }

        public int[] InitialState { get; }

        public bool IsGoal(int[] state)
        {
            for (var i = 0; i < state.GetLength(0); i++)
            {
                if (!CheckNeighbours(i, state[i], state))
                    return false;
            }
            return true;
        }

        private static bool CheckNeighbours(int column, int row, int[] state)
        {
            int tmp = 1, n = state.GetLength(0);
            for (var i = 0; i < n; i++)
            {
                if (column == i)
                {
                    tmp = 1;
                    continue;
                }
                if (state[i] == row)
                {
                    return false;
                }
                if ((column + tmp) < n && ((row + tmp) < n) && ((column + tmp) == i) && ((row + tmp) == state[i]))
                {
                    return false;
                }
                if ((column - tmp) >= 0 && ((row + tmp) < n) && ((column - tmp) == -i) && ((row + tmp) == state[-i]))
                {
                    return false;
                }
                if ((column - tmp) >= 0 && ((row - tmp) >= 0) && ((column - tmp) == -i) && ((row - tmp) == state[-i]))
                {
                    return false;
                }
                if ((column + tmp) < n && ((row - tmp) >= 0) && (column + tmp) == i && (row - tmp) == state[i])
                {
                    return false;
                }
                tmp++;
            }
            return true;
        }

        public IList<int[]> Expand(Node<int[]> node)
        {

            IList<int[]> elements = new List<int[]>();
            var n = node.State.GetLength(0);

            for (var i = 0; i < n; i++)
            {
                #region Up
                var tmp = (int[])node.State.Clone();
                if (tmp[i] < n - 1)
                {
                    tmp[i] += 1;
                }
                else
                {
                    tmp[i] = 0;
                }
                if (!CheckParent(tmp, node.Parent))
                {
                    elements.Add(tmp);
                }
                #endregion
                #region Down
                tmp = (int[])node.State.Clone();
                if (tmp[i] > 0)
                {
                    tmp[i] -= 1;
                }
                else
                {
                    tmp[i] = n - 1;
                }
                if (!CheckParent(tmp, node.Parent))
                {
                    elements.Add(tmp);
                }
                #endregion
            }
            return elements;
        }

        public bool CheckParent(int[] state, Node<int[]> node)
        {
            while (true)
            {
                if (node == null)
                {
                    return false;
                }
                if (Compare(state, node.State))
                {
                    return true;
                }
                node = node.Parent;
            }
        }

        private static int CheckCollisions(int column, int row, int[] state)
        {
            bool topleft = false,
                topright = false,
                bottomleft = false,
                bottomright = false,
                left = false,
                right = false;
            var counter = 0;
            for (var i = 1; i < state.GetLength(0); i++)
            {
                #region Left

                try
                {
                    if (state[column - i] == row && left == false)
                    {
                        counter++;
                        left = true;
                    }
                }
                catch
                {
                    left = true;
                }

                #endregion

                #region Right

                try
                {
                    if (state[column + i] == row && right == false)
                    {
                        counter++;
                        right = true;
                    }
                }
                catch
                {
                    right = true;
                }

                #endregion

                #region TopLeft

                try
                {
                    if (state[column - i] == row - i && topleft == false)
                    {
                        counter++;
                        topleft = true;
                    }
                }
                catch
                {
                    topleft = true;
                }

                #endregion

                #region TopRight

                try
                {
                    if (state[column + i] == row - i && topright == false)
                    {
                        counter++;
                        topright = true;
                    }
                }
                catch
                {
                    topright = true;
                }

                #endregion

                #region BottomRight

                try
                {
                    if (state[column + i] == row + i && bottomright == false)
                    {
                        counter++;
                        bottomright = true;
                    }
                }
                catch
                {
                    bottomright = true;
                }

                #endregion

                #region BottomLeft

                try
                {
                    if (state[column - i] == row + i && bottomleft == false)
                    {
                        counter++;
                        bottomleft = true;
                    }
                }
                catch
                {
                    bottomleft = true;
                }

                #endregion
            }
            return counter;
        }

        public int CountCollisions(Node<int[]> node)
        {
            var collect = 0;
            for (var i = 0; i < node.State.GetLength(0); i++)
            {
                collect += CheckCollisions(i, node.State[i], node.State);
            }
            return collect / 2;
        }
        
        public int CountDepth(Node<int[]> state)
        {
            var result = 0;
            var par = state;
            while (par.Parent != null)
            {
                par = par.Parent;
                result++;
            }
            return result;
        }

        public int Bfs(Node<int[]> state)
        {
            return state.Heuristic = CountCollisions(state);
        }
        
        public int Astar(Node<int[]> state)
        {
            return state.Heuristic = CountCollisions(state) + CountDepth(state);
        }

        public int GetHeuristic(Node<int[]> state)
        {
            return state.Heuristic;
        }

        private static bool Compare(IEnumerable tmp, IEnumerable parent)
        {
            return Equals(tmp, parent);
        }
    }
}
