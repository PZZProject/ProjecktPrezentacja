﻿using System.Collections.Generic;

namespace Projekt
{
    //Problem Osemki, Przesuwanki
    internal class Osemka : IProblem<int[,]>
    {
        public Osemka(int[,] sPocz, int[,] sKon)
        {
            InitialState = sPocz;
            GoalState = sKon;
        }

        public int[,] InitialState { get; }

        public int[,] GoalState { get; }


        public bool IsGoal(int[,] state)
        {
            for (var i = 0; i < state.GetLength(0); i++)
            {
                for (var j = 0; j < state.GetLength(1); j++)
                {
                    if (state[i, j] != GoalState[i, j])
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private static bool Compare(int[,] tmp, Node<int[,]> parent)
        {
            try
            {
                var state = parent.State;
                for (var i = 0; i < state.GetLength(0); i++)
                {
                    for (var j = 0; j < state.GetLength(1); j++)
                    {
                        if (state[i, j] != tmp[i, j])
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public IList<int[,]> Expand(Node<int[,]> node)
        {
            IList<int[,]> elements = new List<int[,]>();
            var state = node.State;
            for (var i = 0; i < state.GetLength(0); i++)
            {
                for (var j = 0; j < state.GetLength(1); j++)
                {
                    if (state[i, j] != 0) continue;

                    #region Top

                    int[,] tmpState;
                    int tmp;
                    try
                    {
                        tmpState = (int[,])state.Clone();
                        tmp = tmpState[i - 1, j];
                        tmpState[i - 1, j] = tmpState[i, j];
                        tmpState[i, j] = tmp;
                        if (!CheckParent(tmpState, node))
                        {
                            elements.Add(tmpState);
                        }
                    }
                    catch
                    {
                        // eventuell catch
                    }
                    #endregion
                    #region Left
                    try
                    {
                        tmpState = (int[,])state.Clone();
                        tmp = tmpState[i, j - 1];
                        tmpState[i, j - 1] = tmpState[i, j];
                        tmpState[i, j] = tmp;
                        if (!CheckParent(tmpState, node))
                        {
                            elements.Add(tmpState);
                        }
                    }
                    catch
                    {
                        //eventually catch
                    }
                    #endregion
                    #region Right
                    try
                    {
                        tmpState = (int[,])state.Clone();
                        tmp = tmpState[i, j + 1];
                        tmpState[i, j + 1] = tmpState[i, j];
                        tmpState[i, j] = tmp;
                        if (!CheckParent(tmpState, node))
                        {
                            elements.Add(tmpState);
                        }
                    }
                    catch
                    {
                        //eventually catch
                    }
                    #endregion
                    #region Bottom
                    try
                    {
                        tmpState = (int[,])state.Clone();
                        tmp = tmpState[i + 1, j];
                        tmpState[i + 1, j] = tmpState[i, j];
                        tmpState[i, j] = tmp;
                        if (!CheckParent(tmpState, node))
                        {
                            elements.Add(tmpState);
                        }
                    }
                    catch
                    {
                        //eventually catch
                    }
                    #endregion
                }
            }
            return elements;
        }

        public bool CheckParent(int[,] state, Node<int[,]> node)
        {
            while (true)
            {
                if (Compare(state, node))
                {
                    return true;
                }
                if (node.Parent == null)
                {
                    return false;
                }
                node = node.Parent;
            }
        }

        public int CountDepth(Node<int[,]> state)
        {
            var result = 0;
            var par = state;
            while (par.Parent != null)
            {
                par = par.Parent;
                result++;
            }
            return result;
        }

        public int CountCollisions(Node<int[,]> node)
        {
            var count = 0;
            for (var i = 0; i < node.State.GetLength(0); i++)
            {
                for (var j = 0; j < node.State.GetLength(1); j++)
                {
                    if (node.State[i, j] != GoalState[i, j])
                        count++;
                }
            }
            return count;
        }

        public int Bfs(Node<int[,]> state)
        {
            return state.Heuristic = CountCollisions(state);
        }
        
        public int Astar(Node<int[,]> state)
        {
            return state.Heuristic = CountCollisions(state) + CountDepth(state);
        }
        
        public int GetHeuristic(Node<int[,]> state)
        {
            return state.Heuristic;
        }
    }
}
